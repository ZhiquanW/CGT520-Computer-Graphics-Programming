#ifndef __CUBE_H__
#define __CUBE_H__

#include <windows.h>
#include <GL/glew.h>

GLuint create_cube_vao();
void draw_cube(GLuint vao);

#endif

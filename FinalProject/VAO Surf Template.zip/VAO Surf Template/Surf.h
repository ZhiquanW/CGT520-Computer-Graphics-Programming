#ifndef __SURF_H__
#define __SURF_H__

#include <windows.h>
#include <GL/glew.h>

GLuint create_surf_vao();
void draw_surf(GLuint vao);

#endif
